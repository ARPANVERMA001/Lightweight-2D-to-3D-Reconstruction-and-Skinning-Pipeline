var namespaces_dup =
[
    [ "Dem", "namespace_dem.html", null ]
];