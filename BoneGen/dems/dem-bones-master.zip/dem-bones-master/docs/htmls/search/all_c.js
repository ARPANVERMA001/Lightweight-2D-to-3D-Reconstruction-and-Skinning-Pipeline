var searchData=
[
  ['transaffine_72',['transAffine',['../class_dem_1_1_dem_bones.html#a53f9859cd63a8c51f6f50fdfa7251681',1,'Dem::DemBones']]],
  ['transaffinenorm_73',['transAffineNorm',['../class_dem_1_1_dem_bones.html#a3b125934b440ebcebb3ba44acda41366',1,'Dem::DemBones']]],
  ['transvec_74',['transVec',['../_mat_blocks_8h.html#a59df0c210b2ea616135f313a28a5333d',1,'MatBlocks.h']]],
  ['triplet_75',['Triplet',['../class_dem_1_1_dem_bones.html#ac6f69fb5e7a91330f21f48ad9f019212',1,'Dem::DemBones::Triplet()'],['../class_dem_1_1_dem_bones_ext.html#aedb230a6a7eede0d751355b385e58938',1,'Dem::DemBonesExt::Triplet()']]]
];
