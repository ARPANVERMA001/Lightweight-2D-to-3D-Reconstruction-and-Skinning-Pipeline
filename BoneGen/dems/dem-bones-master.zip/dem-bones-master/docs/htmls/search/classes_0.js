var searchData=
[
  ['convexls_87',['ConvexLS',['../class_dem_1_1_convex_l_s.html',1,'Dem']]]
];
