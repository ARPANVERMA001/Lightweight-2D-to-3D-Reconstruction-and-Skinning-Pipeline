var searchData=
[
  ['transaffine_155',['transAffine',['../class_dem_1_1_dem_bones.html#a53f9859cd63a8c51f6f50fdfa7251681',1,'Dem::DemBones']]],
  ['transaffinenorm_156',['transAffineNorm',['../class_dem_1_1_dem_bones.html#a3b125934b440ebcebb3ba44acda41366',1,'Dem::DemBones']]]
];
