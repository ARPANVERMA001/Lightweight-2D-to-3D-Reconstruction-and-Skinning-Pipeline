var searchData=
[
  ['solve_69',['solve',['../class_dem_1_1_convex_l_s.html#a68f946876bc5259e699f0c311d18e266',1,'Dem::ConvexLS']]],
  ['sparsematrix_70',['SparseMatrix',['../class_dem_1_1_dem_bones.html#aa8ea3a6b166652e954decbf135b3255b',1,'Dem::DemBones::SparseMatrix()'],['../class_dem_1_1_dem_bones_ext.html#a039349271cd9bd256ba359f0eab2ac7c',1,'Dem::DemBonesExt::SparseMatrix()']]],
  ['subjectid_71',['subjectID',['../class_dem_1_1_dem_bones.html#ac99a3d810ab4fc1286e9677ce5c322b0',1,'Dem::DemBones']]]
];
