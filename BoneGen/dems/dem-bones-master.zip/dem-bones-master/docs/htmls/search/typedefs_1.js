var searchData=
[
  ['sparsematrix_167',['SparseMatrix',['../class_dem_1_1_dem_bones.html#aa8ea3a6b166652e954decbf135b3255b',1,'Dem::DemBones::SparseMatrix()'],['../class_dem_1_1_dem_bones_ext.html#a039349271cd9bd256ba359f0eab2ac7c',1,'Dem::DemBonesExt::SparseMatrix()']]]
];
