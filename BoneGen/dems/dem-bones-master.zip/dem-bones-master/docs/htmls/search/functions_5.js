var searchData=
[
  ['solve_128',['solve',['../class_dem_1_1_convex_l_s.html#a68f946876bc5259e699f0c311d18e266',1,'Dem::ConvexLS']]]
];
