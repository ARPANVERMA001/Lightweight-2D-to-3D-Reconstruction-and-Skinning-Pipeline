var class_dem_1_1_convex_l_s =
[
    [ "MatrixX", "class_dem_1_1_convex_l_s.html#ae6da3230d1826b15b369e6879cbb7191", null ],
    [ "VectorX", "class_dem_1_1_convex_l_s.html#a066dff3827a4d933cfed98276e8d41d0", null ],
    [ "ConvexLS", "class_dem_1_1_convex_l_s.html#a42f2e62346ddc90f930d0d473773fd06", null ],
    [ "init", "class_dem_1_1_convex_l_s.html#ac601e6ddfcad0b277ad805449b3510f3", null ],
    [ "solve", "class_dem_1_1_convex_l_s.html#a68f946876bc5259e699f0c311d18e266", null ]
];