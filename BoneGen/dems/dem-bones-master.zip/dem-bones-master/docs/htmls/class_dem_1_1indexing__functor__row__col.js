var class_dem_1_1indexing__functor__row__col =
[
    [ "MatrixType", "class_dem_1_1indexing__functor__row__col.html#a3b60c9d162a386342f729652fad60710", null ],
    [ "indexing_functor_row_col", "class_dem_1_1indexing__functor__row__col.html#a8a7c618f00b1188ffae30d8bf093791f", null ],
    [ "operator()", "class_dem_1_1indexing__functor__row__col.html#ac6067acba820bc79ac95155ab6953997", null ]
];